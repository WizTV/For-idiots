#include <iostream>
#include <cstring>
using namespace std;


class przedmiot
{
    protected:
        string nazwa;
        string typ;
        string producent;
        short rok;
    public:
        przedmiot();
        przedmiot(string n,string t,string p,short r);
        void wczytaj()
        {
            cout<<"Podaj nazwe: "<<endl;
            getline(cin,nazwa);
            cout<<"Podaj typ: "<<endl;
            getline(cin,typ);
            cout<<"Podaj producenta: "<<endl;
            getline(cin,producent);
            cout<<"Podaj rok produkcji: "<<endl;
            cin>>rok;
        }
        void wypisz()
        {
            cout<<"Nazwa: "<<nazwa<<endl;
            cout<<"Typ: "<<typ<<endl;
            cout<<"Producent: "<<producent<<endl;
            cout<<"Rok produkcji: "<<rok<<endl;
        }
};

przedmiot::przedmiot()
{
    nazwa="";
    typ="";
    producent="";
    rok=NULL;
}

przedmiot::przedmiot(string n,string t,string p,short r)
{
    nazwa=n;
    typ=t;
    producent=p;
    rok=r;
}


void zadanie1()
{
    przedmiot P1,P2;
    cout << "Wypisz dane przedmiotu P1" << endl;
    P1.wczytaj();
    cout << "Wypisz dane przedmiotu P2" << endl;
    P2.wczytaj();
    P1.wypisz();
    cout<<"---------------------------"<<endl;
    P2.wypisz();
}

class ksiazka
{
    protected:
        string tytul;
        string autor;
        string wyd;
        short rok;
        short cena;
    public:
        ksiazka();
        ksiazka(string t,string a,string w,short r, short c);
        ~ksiazka();
        void wczytajTytul()
        {
            cout<<"Podaj tytul: "<<endl;
            getline(cin,tytul);
        }
        void wczytajAutora()
        {
            cout<<"Podaj autora: "<<endl;
            getline(cin,autor);
        }
        void wczytajWydawnictwo()
        {
            cout<<"Podaj wydawnictwo: "<<endl;
            getline(cin,wyd);
        }
        void wczytajRokWydania()
        {
            cout<<"Podaj rok wydania: "<<endl;
            cin>>rok;
        }
        void wczytajCene()
        {
            cout<<"Podaj cene: "<<endl;
            cin>>cena;
        }
        void wypiszTytul()
        {
            cout<<"Tytul: "<<tytul<<endl;
        }
        void wypiszAutora()
        {
            cout<<"Autor: "<<autor<<endl;
        }
        void wypiszWydawnictwo()
        {
            cout<<"Wydawnictwo: "<<wyd<<endl;
        }
        void wypiszRokWydania()
        {
            cout<<"Rok wydania: "<<rok<<endl;
        }
        void wypiszCene()
        {
            cout<<"Cena: "<<cena<<endl;
        }
};
ksiazka::ksiazka()
{
    tytul="";
    autor="";
    wyd="";
    rok=NULL;
    cena=NULL;
}
ksiazka::ksiazka(string t,string a,string w,short r, short c)
{
    tytul=t;
    autor=a;
    wyd=w;
    rok=r;
    cena=c;
}
ksiazka::~ksiazka()
{}
void zadanie2()
{
    ksiazka *K1,*K2;
    K1 = new ksiazka();
    K2 = new ksiazka();
    K1->wczytajTytul();
    K1->wczytajAutora();
    K1->wczytajWydawnictwo();
    K1->wczytajRokWydania();
    K1->wczytajCene();
    K2->wczytajTytul();
    K2->wczytajAutora();
    K2->wczytajWydawnictwo();
    K2->wczytajRokWydania();
    K2->wczytajCene();
    K1->wypiszTytul();
    K1->wypiszAutora();
    K1->wypiszWydawnictwo();
    K1->wypiszRokWydania();
    K1->wypiszCene();
    K2->wypiszTytul();
    K2->wypiszAutora();
    K2->wypiszWydawnictwo();
    K2->wypiszRokWydania();
    K2->wypiszCene();
}
class osoba
{
    protected:
        string nazwisko;
        string imie;
        short wiek;
    public:
        osoba();
        void coutNazwisko(){}
        void coutImie(){}
        void coutWiek(){}
        void cinNazwisko(string i){}
        void cinImie(string i){}
        void cinWiek(short w){}
};
osoba::osoba()
{}

class nauczyciel : public osoba
{
    protected:
        short staz;
        string przedmiot;
    public:
        nauczyciel();
        void coutStaz(){}
        void coutPrzedmiot(){}
        void cinStaz(short s){}
        void cinPrzedmiot(string p){}
};
nauczyciel::nauczyciel():osoba()
{}

class uczen : public osoba
{
    protected:
         double srednia_ocen;
         short rok_rozpoczecia;
    public:
        uczen();
        void coutSredniaOcen(){}
        void coutRokRozpoczecia(){}
        void cinSredniaOcen(double s){}
        void cinRokRozpoczecia(short rr){}
};
uczen::uczen():osoba()
{}

class absolwent : public uczen
{
    protected:
        short rok_zakonczenia;
    public:
        absolwent();
        void coutRokZakonczenia(){}
        void cinRokZakonczenia(short z){}
};
absolwent::absolwent():uczen()
{}
void zadanie3()
{
    uczen uczen;
    nauczyciel nauczyciel;
    absolwent absolwent;
}

int main()
{
    zadanie1();
//    zadanie2();
//    zadanie3();
    return 0;
}
